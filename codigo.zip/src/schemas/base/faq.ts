export const faqItems = [
  {
    question: "Este ebook é apenas para mulheres?",
    answer:
      "Não, ele é desenvolvido para o público feminino, mas pode ser adquirido por todos que queiram a proteção das mulheres."
  },
  {
    question: "É seguro comprar?",
    answer: "Sim, nossa forma de pagamento é pelo Mercado Pago."
  },
  {
    question: "O ebook têm muitas páginas?",
    answer: "É um ebook amplo, porém direto ao ponto."
  },
  {
    question: "Como recebo o ebook?",
    answer: "Após a compra é automaticamente enviado para seu email."
  },
  {
    question: "Preciso fornecer meus dados?",
    answer:
      "Para se cadastrar no site apenas seu nome e email, no Mercado Pago dependerá de sua forma de pagamento."
  }
]
